
typedef Vector Angle;
typedef Vector QAngle;
/*
TODO:
Eventually make an Angle class with Angle-specific functions such as normalizing.
*/