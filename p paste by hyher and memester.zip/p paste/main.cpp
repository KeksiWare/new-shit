#include "sdk.h"
#include "hooks.h"
#include "Menu.h"
#include "MaterialHelper.h"
#include "BacktrackingHelper.h"
#include "security.h"
#include "Math.h"
#include "global.h"
#include <dbghelp.h>
#include <tchar.h>
#include "Config.h"
#include "ScreenEffects.h"
#include "xd.h"
HINSTANCE hAppInstance;
CClient* g_pClient;
CClientEntityList* g_pEntitylist;
CEngine* g_pEngine;
CInput* g_pInput;
CModelInfo* g_pModelInfo;
CInputSystem* g_pInputSystem;
CPanel* g_pPanel;
CSurface* g_pSurface;
CEngineTrace* g_pEngineTrace;
CDebugOverlay* g_pDebugOverlay;
IPhysicsSurfaceProps* g_pPhysics;
CRenderView* g_pRenderView;
CClientModeShared* g_pClientMode;
CGlobalVarsBase* g_pGlobals;
CModelRender* g_pModelRender;
CGlowObjectManager* g_GlowObjManager;
CMaterialSystem* g_pMaterialSystem;
IMoveHelper* g_pMoveHelper;
CPrediction* g_pPrediction;
CGameMovement* g_pGameMovement;
IGameEventManager* g_pGameEventManager;
IEngineVGui* g_pEngineVGUI;
ICvar* g_pCvar;
CInterfaces Interfaces;
CCRC gCRC;
C_TEFireBullets* g_pFireBullet;
IViewRenderBeams* g_pViewRenderBeams;


vfunc_hook panel;
vfunc_hook clientmode;
vfunc_hook enginevgui;
vfunc_hook modelrender;
vfunc_hook client;
vfunc_hook firebullet;
vfunc_hook d3d9;
vfunc_hook renderview;
vfunc_hook g_pd3d;
vfunc_hook gpclientmodehook;


HMODULE h_ThisModule;
void Init()
{
	SetupOffsets();
	g_MaterialHelper = new CMaterialHelper();
	g_Event.RegisterSelf();
	srand(time(0));
	ConSys->CheckConfigs();
	ConSys->Handle();
	panel.setup(g_pPanel);
	panel.hook_index(41, Hooks::PaintTraverse);
	g_GlowObjManager = *(CGlowObjectManager**)(FindPatternIDA("client.dll", "0F 11 05 ? ? ? ? 83 C8 01 C7 05 ? ? ? ? 00 00 00 00") + 3);
	clientmode.setup(g_pClientMode);
	clientmode.hook_index(24, Hooks::CreateMove);
	clientmode.hook_index(18, Hooks::OverrideView);
	gpclientmodehook.setup(g_pClientMode);
	gpclientmodehook.hook_index(44, hkDoPostScreenSpaceEffects);
	gpclientmodehook.hook_index(35, GGetViewModelFOV);
	renderview.setup(g_pRenderView);
	renderview.hook_index(9, Hooks::scene_end);
	modelrender.setup(g_pModelRender);
	modelrender.hook_index(21, Hooks::DrawModelExecute);
	client.setup(g_pClient);
	client.hook_index(37, Hooks::FrameStageNotify);
	auto dwDevice = **(uint32_t**)(FindPatternIDA(XorStr("shaderapidx9.dll"), XorStr("A1 ? ? ? ? 50 8B 08 FF 51 0C")) + 1);
	d3d9.setup((void*)dwDevice);
	d3d9.hook_index(42, Hooks::D3D9_EndScene);
	g_pd3d.setup((DWORD**)dwDevice);
	g_pd3d.hook_index(16, Hooks::hkdReset);
	Hooks::g_pOldWindowProc = (WNDPROC)SetWindowLongPtr(G::Window, GWLP_WNDPROC, (LONG_PTR)Hooks::WndProc);
}

void StartCheat()
{
	if (Interfaces.GetInterfaces() && g_pPanel && g_pClientMode)
	{
		Sleep(500);
		Init();
	}
}

BOOL WINAPI DllMain(HINSTANCE Instance, DWORD dwReason, LPVOID lpReserved)
{
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		DisableThreadLibraryCalls(Instance);
		G::Window = FindWindowA(("Valve001"), 0);
		CreateThread(0, 0, (LPTHREAD_START_ROUTINE)StartCheat, 0, 0, 0);
		break;
	}
	return true;
}

MsgFn oMsg;

void __cdecl Msg(char const* msg, ...)
{
	//DOES NOT CRASH
	if(!oMsg)
		oMsg = (MsgFn)GetProcAddress(GetModuleHandle(XorStr("tier0.dll")), XorStr("Msg"));

	char buffer[989];
	va_list list;
	va_start(list, msg);
	vsprintf_s(buffer, msg, list);
	va_end(list);
	oMsg(buffer, list);
}